﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace chp4_prob7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal income;    //收入
            decimal taxrate;   //稅率
            decimal payable;   //應交稅額
            decimal netIncome; //淨收入
            
            //以下作答
            income=decimal.Parse(incomeTextBox.Text);
            
            if ( income>= 0 &&income <= 590000)
            {
                payable = income * 0.05m;  // 5%
            }
            else if (income >= 590001&&income <= 1330000)
            {
                payable = 590000 * 0.05m + (income - 590000) * 0.12m;  // 5% + 12%
            }
            else if (income>= 1330001 && income <= 2660000)
            {
                payable = 590000 * 0.05m + (1330000 - 590000) * 0.12m + (income - 1330000) * 0.20m;  // 5% + 12% + 20%
            }
            else if (income>= 2660001&&income <= 4980000)
            {
                payable = 590000 * 0.05m + (1330000 - 590000) * 0.12m + (2660000 - 1330000) * 0.20m + (income - 2660000) * 0.30m;  // 5% + 12% + 20% + 30%
            }
            else
            {
                payable = 590000 * 0.05m + (1330000 - 590000) * 0.12m + (2660000 - 1330000) * 0.20m + (4980000 - 2660000) * 0.30m + (income - 4980000) * 0.40m;  // 5% + 12% + 20% + 30% + 40%
            }

          netIncome = income-payable;

            label2.Text ="Payable Tax:"+ payable.ToString("c");
            label3.Text = "Net Income:"+ netIncome.ToString("c");


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
